<?php
//if (!function_exists('catch_message')){
//    function catch_message($isSuccess = false,$message = 'Validation errors'){
//        return response()->json([
//            'success'   => false,
//            'message'   => 'Validation errors',
//            'data'      => $validator->errors()
//        ])
//    }
//}
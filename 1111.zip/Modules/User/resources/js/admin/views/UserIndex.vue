<template>
    <BlogList />
</template>

<script>
import BlogList from '../components/BlogList.vue';

export default {
    components: {
        BlogList,
    },
};
</script>

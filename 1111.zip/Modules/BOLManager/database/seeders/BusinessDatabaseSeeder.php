<?php

namespace Modules\Business\database\seeders;

use Illuminate\Database\Seeder;

class BusinessDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

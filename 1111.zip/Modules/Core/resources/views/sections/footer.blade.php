<footer class="adminuiux-footer mt-auto">

</footer>
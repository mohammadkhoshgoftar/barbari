<script defer="defer" src="{{ asset('admin/assets/js/app8032.js?6b53ec3d433ab1dff13c') }}"></script>
<link href="{{ asset('admin/assets/css/app8032.css?6b53ec3d433ab1dff13c') }}" rel="stylesheet">
<link href="{{ asset('admin/assets/css/amir.css') }}" rel="stylesheet">
<link href="{{asset('admin/assets/css/fontawesome.css')}}" rel="stylesheet">
<link href="{{asset('admin/assets/css/light.css')}}" rel="stylesheet">
<link href="{{asset('package/fontawesome-free-6.7.2/css/all.css')}}" rel="stylesheet">
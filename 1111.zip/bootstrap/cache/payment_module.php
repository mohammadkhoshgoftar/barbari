<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Payment\\Providers\\PaymentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Payment\\Providers\\PaymentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
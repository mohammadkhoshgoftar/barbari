<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Message\\Providers\\MessageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Message\\Providers\\MessageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);
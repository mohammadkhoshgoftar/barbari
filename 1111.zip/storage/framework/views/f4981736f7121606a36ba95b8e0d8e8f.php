<style>
    .toast-container-center-top {
        position: fixed;
        top: 20px;
        /* فاصله از بالای صفحه */
        left: 50%;
        /* قرار گرفتن در وسط */
        transform: translateX(-50%);
        z-index: 1055;
        /* بالاتر از عناصر دیگر */
    }

    .toast-body {
        height: 100%;
        /* تنظیم ارتفاع برای مرکزیت عمودی */
    }
</style>
<?php if($errors->any()): ?>
    <div id="validationToast" class="toast bg-danger text-white toast-container-center-top" role="alert"
         aria-live="assertive" aria-atomic="true" data-bs-delay="300000">
        <div class="toast-header">
            <strong class="text-center">خطاهای اعتبارسنجی</strong>
            
        </div>
        <div class="toast-body">
            <ul class="mb-0">
                لطفا خطا های اعتبار سنجی رو برطرف کنید و دوباره درخواست خود را ثبت کنید
            </ul>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var toastElement = document.getElementById('validationToast');
            var toast = new bootstrap.Toast(toastElement);
            toast.show();
        });
    </script>
<?php endif; ?>
<?php if(session('toast_message')): ?>

    <?php if(session('toast_message')): ?>
        <div id="liveToast"
             class="toast rounded-3 <?php echo e(session('status') == 'success' ? 'bg-teal' : ''); ?><?php echo e(session('status') == 'error' ? 'bg-red' : ''); ?>  text-white toast-container-center-top"
             role="alert"
             aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
            <div class="toast-body d-flex align-items-center justify-content-center">
                <?php echo e(session('toast_message')); ?>

            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var toastElement = document.getElementById('liveToast');
                var toast = new bootstrap.Toast(toastElement);
                toast.show();
            });
        </script>
    <?php endif; ?>

<?php endif; ?><?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/Core/resources/views/sections/toast.blade.php ENDPATH**/ ?>
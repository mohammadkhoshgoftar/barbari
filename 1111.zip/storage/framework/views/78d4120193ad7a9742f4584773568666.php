<footer class="adminuiux-footer mt-auto">

</footer><?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/Core/resources/views/sections/footer.blade.php ENDPATH**/ ?>
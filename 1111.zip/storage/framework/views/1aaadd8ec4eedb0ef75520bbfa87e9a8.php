<div class="card adminuiux-card mt-3 mb-3">
    <div class="card-body pt-0">
        <table id="dataTable<?php echo e($table); ?>" class="table w-100 nowrap">
            <thead>
            <tr>
                <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th
                            <?php if(isset($column['breakpoints'])): ?>
                                data-breakpoints="<?php echo e($column['breakpoints']); ?>"
                            <?php endif; ?>
                            <?php if(isset($column['class'])): ?>
                                class="<?php echo e($column['class']); ?>"
                            <?php endif; ?>
                    >
                        <?php echo e($column['name']); ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            </thead>
        </table>
    </div>
</div>

<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#dataTable<?php echo e($table); ?>').DataTable({
            processing: true,
            serverSide: true,
            bDestroy: true,
            stateSave: true,
            ajax: '<?php echo e($route); ?>',
            columns: [
                    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    data: '<?php echo e($column['data']); ?>',
                    name: '<?php echo e($column['name']); ?>',
                    title: '<?php echo e($column['label'] ?? $column['name']); ?>',
                    <?php if(isset($column['orderable']) && !$column['orderable']): ?>
                    orderable: false,
                    <?php endif; ?>
                            <?php if(isset($column['searchable']) && !$column['searchable']): ?>
                    searchable: false,
                    <?php endif; ?>
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            responsive: true,
            "language": {
                "lengthMenu": "نمایش _MENU_ رکورد در هر صفحه",
                "zeroRecords": "هیچ موردی یافت نشد",
                "info": "نمایش صفحه _PAGE_ از _PAGES_",
                "infoEmpty": "رکوردی موجود نیست",
                "infoFiltered": "(فیلتر شده از _MAX_ رکورد)",
                "search": "جستجو:",
                "paginate": {
                    "first": "اول",
                    "last": "آخر",
                    "next": "بعدی",
                    "previous": "قبلی"
                },
                "loadingRecords": "در حال بارگذاری...",
                "processing": "در حال پردازش...",
                "emptyTable": "اطلاعاتی در جدول وجود ندارد"
            }
        });
    });
</script>
<?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/Core/resources/views/components/data-table-component.blade.php ENDPATH**/ ?>
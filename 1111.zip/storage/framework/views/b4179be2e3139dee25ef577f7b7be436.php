<script defer="defer" src="<?php echo e(asset('admin/assets/js/app8032.js?6b53ec3d433ab1dff13c')); ?>"></script>
<link href="<?php echo e(asset('admin/assets/css/app8032.css?6b53ec3d433ab1dff13c')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin/assets/css/amir.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin/assets/css/fontawesome.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('admin/assets/css/light.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('package/fontawesome-free-6.7.2/css/all.css')); ?>" rel="stylesheet"><?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/Core/resources/views/sections/style.blade.php ENDPATH**/ ?>
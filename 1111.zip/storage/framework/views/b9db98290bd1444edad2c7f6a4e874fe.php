<?php $__env->startSection('content'); ?>

<main class="adminuiux-content has-sidebar" onclick="contentClick()">
    <div class="container-fluid mt-2">
        <div class="bg-theme-1-subtle rounded px-2 py-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item bi"><a href="<?php echo e(route('dashboard')); ?>">داشبورد</a></li>
                    <i class="fa-light fa-angle-left"></i>
                    <li class="breadcrumb-item bi"><a href="<?php echo e(route('admin.bols')); ?>">بارنامه ها</a></li>
                    <i class="fa-light fa-angle-left"></i>
                    <li class="breadcrumb-item active bi" aria-current="page">ایجاد بارنامه</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="container mt-3" id="main-content">
        <div class="align-items-center card d-flex flex-row mb-3 gap-2 p-2 rounded-4">
            <div class="bg-teal text-white px-3 py-1 rounded">
                <i class="fas fa-info"></i>
            </div>
            <h6>در این قسمت میتوانید محصول جدید اضافه کنید</h6>
        </div>

        <div class="card rounded-4">
            <div class="card-body">
                <form action="<?php echo e(route('admin.bol.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-12">
                            <h5 class="mt-4">اطلاعات فرستنده</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="sender_name">نام فرستنده</label>
                            <input type="text" name="sender_name" id="sender_name" class="form-control" placeholder="نام فرستنده" value="<?php echo e(old('sender_name')); ?>">
                            <?php $__errorArgs = ['sender_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="sender_national_code">کد ملی فرستنده</label>
                            <input type="number" name="sender_national_code" id="sender_national_code" class="form-control" placeholder="کد ملی" value="<?php echo e(old('sender_national_code')); ?>">
                            <?php $__errorArgs = ['sender_national_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="sender_postal_code">کد پستی فرستنده</label>
                            <input type="number" name="sender_postal_code" id="sender_postal_code" class="form-control" placeholder="کد پستی" value="<?php echo e(old('sender_postal_code')); ?>">
                            <?php $__errorArgs = ['sender_postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>






                        <div class="col-12">
                            <h5 class="mt-4">اطلاعات گیرنده</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="receiver_name">نام گیرنده</label>
                            <input type="text" name="receiver_name" id="receiver_name" class="form-control" placeholder="نام گیرنده" value="<?php echo e(old('receiver_name')); ?>">
                            <?php $__errorArgs = ['receiver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="receiver_national_code">کد ملی گیرنده</label>
                            <input type="number" name="receiver_national_code" id="receiver_national_code" class="form-control" placeholder="کد ملی" value="<?php echo e(old('receiver_national_code')); ?>">
                            <?php $__errorArgs = ['receiver_national_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="receiver_postal_code">کد پستی گیرنده</label>
                            <input type="number" name="receiver_postal_code" id="receiver_postal_code" class="form-control" placeholder="کد پستی" value="<?php echo e(old('receiver_postal_code')); ?>">
                            <?php $__errorArgs = ['receiver_postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>






                        <div class="col-12">
                            <h5 class="mt-4">اطلاعات بارنامه</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <?php if (isset($component)) { $__componentOriginalcdb481d4fd5f9b34aef92be68e80779b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcdb481d4fd5f9b34aef92be68e80779b = $attributes; } ?>
<?php $component = Modules\Core\app\View\Components\DatePickerComponent::resolve(['id' => 'waybill_date','name' => 'waybill_date','inputClass' => 'form-control','label' => 'تاریخ بارنامه','placeholder' => 'تاریخ بارنامه','options' => '{observer: true, format: \'YYYY/MM/DD\', altField: \'.observer-example-alt\'}','value' => ''.e(old('waybill_date')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('persian-datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Modules\Core\app\View\Components\DatePickerComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcdb481d4fd5f9b34aef92be68e80779b)): ?>
<?php $attributes = $__attributesOriginalcdb481d4fd5f9b34aef92be68e80779b; ?>
<?php unset($__attributesOriginalcdb481d4fd5f9b34aef92be68e80779b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcdb481d4fd5f9b34aef92be68e80779b)): ?>
<?php $component = $__componentOriginalcdb481d4fd5f9b34aef92be68e80779b; ?>
<?php unset($__componentOriginalcdb481d4fd5f9b34aef92be68e80779b); ?>
<?php endif; ?>
                            <?php $__errorArgs = ['waybill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="waybill_time">ساعت بارنامه</label>
                            <input type="time" name="waybill_time" id="waybill_time" class="form-control" value="<?php echo e(old('waybill_time')); ?>">
                            <?php $__errorArgs = ['waybill_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>






                        <div class="col-12">
                            <h5 class="mt-4">اطلاعات بیمه</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="insurance_contract_number">شماره قرارداد بیمه</label>
                            <input type="text" name="insurance_contract_number" id="insurance_contract_number" class="form-control" placeholder="شماره قرارداد بیمه" value="<?php echo e(old('insurance_contract_number')); ?>">
                            <?php $__errorArgs = ['insurance_contract_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="insurance_company_name">نام شرکت بیمه</label>
                            <input type="text" name="insurance_company_name" id="insurance_company_name" class="form-control" placeholder="نام شرکت بیمه" value="<?php echo e(old('insurance_company_name')); ?>">
                            <?php $__errorArgs = ['insurance_company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="insurance_value">ارزش بیمه</label>
                            <input type="text" name="insurance_value" id="insurance_value" class="form-control" placeholder="ارزش بیمه" value="<?php echo e(old('insurance_value')); ?>">
                            <?php $__errorArgs = ['insurance_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12">
                            <h5 class="mt-4">اطلاعات مبدا و مقصد</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="loading_origin">مبدا بارگیری</label>
                            <input type="text" name="loading_origin" id="loading_origin" class="form-control" placeholder="مبدا بارگیری" value="<?php echo e(old('loading_origin')); ?>">
                            <?php $__errorArgs = ['loading_origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-6">
                            <label class="mb-2" for="unloading_destination">مقصد تخلیه</label>
                            <input type="text" name="unloading_destination" id="unloading_destination" class="form-control" placeholder="مقصد تخلیه" value="<?php echo e(old('unloading_destination')); ?>">
                            <?php $__errorArgs = ['unloading_destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12">
                            <h5 class="mt-4">اطلاعات راننده</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="text" name="drivers[0][driver_name]" class="form-control" placeholder="نام راننده" value="<?php echo e(old('drivers.0.driver_name')); ?>">
                            <?php $__errorArgs = ['drivers.0.driver_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="number" name="drivers[0][driver_national_code]" class="form-control" placeholder="کد ملی راننده" value="<?php echo e(old('drivers.0.driver_national_code')); ?>">
                            <?php $__errorArgs = ['drivers.0.driver_national_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="tel" name="drivers[0][driver_mobile]" class="form-control" placeholder="موبایل راننده" value="<?php echo e(old('drivers.0.driver_mobile')); ?>">
                            <?php $__errorArgs = ['drivers.0.driver_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="text" name="drivers[0][fleet_card_number]" class="form-control" placeholder="کارت ناوگان" value="<?php echo e(old('drivers.0.fleet_card_number')); ?>">
                            <?php $__errorArgs = ['drivers.0.fleet_card_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="text" name="drivers[0][fleet_plate]" class="form-control" placeholder="پلاک ناوگان" value="<?php echo e(old('drivers.0.fleet_plate')); ?>">
                            <?php $__errorArgs = ['drivers.0.fleet_plate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="number" name="drivers[0][driver_license_number]" class="form-control" placeholder="شماره گواهینامه" value="<?php echo e(old('drivers.0.driver_license_number')); ?>">
                            <?php $__errorArgs = ['drivers.0.driver_license_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>












                        <div class="col-12">
                            <h5 class="mt-4">اطلاعات محموله</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="text" name="cargos[0][cargo_name]" class="form-control" placeholder="نام محموله" value="<?php echo e(old('cargos.0.cargo_name')); ?>">
                            <?php $__errorArgs = ['cargos.0.cargo_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="number" name="cargos[0][cargo_weight]" class="form-control" placeholder="وزن محموله" value="<?php echo e(old('cargos.0.cargo_weight')); ?>">
                            <?php $__errorArgs = ['cargos.0.cargo_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-2">
                            <input type="number" name="cargos[0][cargo_quantity]" class="form-control" placeholder="تعداد" value="<?php echo e(old('cargos.0.cargo_quantity')); ?>">
                            <?php $__errorArgs = ['cargos.0.cargo_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-2">
                            <input type="text" name="cargos[0][cargo_packaging]" class="form-control" placeholder="نوع بسته‌بندی" value="<?php echo e(old('cargos.0.cargo_packaging')); ?>">
                            <?php $__errorArgs = ['cargos.0.cargo_packaging'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="col-12">
                            <h5 class="mt-4">هزینه باربری</h5>
                            <hr/>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="text" name="rent_cost" id="rent_cost" class="form-control" placeholder="کرایه" value="<?php echo e(old('rent_cost')); ?>">
                            <?php $__errorArgs = ['rent_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-lg-4">
                            <input type="text" name="labor_cost" id="labor_cost" class="form-control" placeholder="کارگری" value="<?php echo e(old('labor_cost')); ?>">
                            <?php $__errorArgs = ['labor_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3 col-12 text-start">
                            <button type="submit" class="btn btn-theme">
                                <i class="fal fa-add"></i>
                                ثبت و چاپ بارنامه
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        const priceInput = document.getElementById('insurance_value');
        priceInput.addEventListener('input', function () {
            let rawValue = this.value.replace(/,/g, '').replace(/[^0-9]/g, '');
            let formattedValue = rawValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            this.value = formattedValue;
        });

        const priceInput2 = document.getElementById('rent_cost');
        priceInput2.addEventListener('input', function () {
            let rawValue = this.value.replace(/,/g, '').replace(/[^0-9]/g, '');
            let formattedValue = rawValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            this.value = formattedValue;
        });

        const priceInput3 = document.getElementById('labor_cost');
        priceInput3.addEventListener('input', function () {
            let rawValue = this.value.replace(/,/g, '').replace(/[^0-9]/g, '');
            let formattedValue = rawValue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            this.value = formattedValue;
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const timeInput = document.getElementById('waybill_time');

            timeInput.addEventListener('change', function() {
                let value = timeInput.value;

                if (!value) return; // اگه خالیه کاری نکن

                let parts = value.split(':');
                let hour = parseInt(parts[0], 10);
                let minute = parseInt(parts[1], 10);

                if (isNaN(hour) || hour < 0 || hour > 23 || isNaN(minute) || minute < 0 || minute > 59) {
                    alert('ساعت وارد شده نامعتبر است. لطفاً بین 00:00 تا 23:59 وارد کنید.');
                    timeInput.value = "";
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('core::layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/BOLManager/resources/views/admin/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<main class="adminuiux-content has-sidebar" onclick="contentClick()">
    <div class="container w-100 mt-3" id="main-content">












        <div class="adminuiux-card mb-3">
            <div class="row">
































































            </div>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('core::layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/Core/resources/views/Admin/dashboard.blade.php ENDPATH**/ ?>
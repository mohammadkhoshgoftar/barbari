<div class="persian-datepicker-wrapper">
    <label class="mb-2" for="<?php echo e($id); ?>"><?php echo e($label); ?></label>
    <input
            id="<?php echo e($id); ?>"
            name="<?php echo e($name); ?>"
            type="text"
            class="<?php echo e($inputClass); ?>"
            value="<?php echo e($value); ?>"
            <?php echo e($enable ?? 'disabled'); ?>

            placeholder="<?php echo e($placeholder); ?>"
    />
</div>

<link rel="stylesheet" href="<?php echo e(asset('package/persianDatePicker/kamadatepicker.min.css')); ?>">

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('package/persianDatePicker/kamadatepicker.min.js')); ?>"></script>
    <script>

        
        

        kamaDatepicker("<?php echo e($id); ?>", {
            buttonsColor: "red",
            forceFarsiDigits: true,
            closeAfterSelect: true,
            nextButtonIcon: "fa fa-arrow-circle-right",
            previousButtonIcon: "fa fa-arrow-circle-left",
            markToday: true,
            markHolidays: true,
            highlightSelectedDay: true,
            sync: false,
            gotoToday: false,
            placeholder: "string",
        });
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/Core/resources/views/components/date-picker-component.blade.php ENDPATH**/ ?>
<div class="adminuiux-sidebar">
    <div class="adminuiux-sidebar-inner">
        <ul class="nav flex-column menu-active-line">
            <hr>
            <li class="nav-item">
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
                    <i class="fa-light fa-house ms-3"></i>
                    <span class="menu-name">داشبورد</span>
                </a>
            </li>
            <?php $__currentLoopData = $moduleNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moduleName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(config(strtolower($moduleName) . '.sideBar')): ?>
                    <?php $__currentLoopData = config(strtolower($moduleName) . '.sideBar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideBar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(auth()->user()->can($sideBar['permission'])): ?>
                            <li class="nav-item dropdown">
                                <a href="javascrit:void(0)"
                                   class="nav-link dropdown-toggle"
                                   data-bs-toggle="dropdown">
                                    <i class="<?php echo e(@$sideBar['icon']); ?> ms-3"></i>
                                    <span
                                            class="menu-name"><?php echo e($sideBar['title']); ?></span><i
                                            class="fa fa-angle-down"></i>
                                </a>


                                <?php if(count($sideBar['child'])): ?>
                                    <div class="dropdown-menu">
                                        <?php $__currentLoopData = $sideBar['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="nav-item"><a href="<?php echo e(route($child['route'])); ?>"
                                                                     class="nav-link">
                                                    <i class="<?php echo e(@$child['icon']); ?> ms-3"></i>
                                                    <span class="menu-name"><?php echo e($child['title']); ?></span></a></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/Core/resources/views/sections/sidebar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<main class="adminuiux-content has-sidebar" onclick="contentClick()">
    <div class="container-fluid mt-2">
        <div class="bg-theme-1-subtle rounded px-2 py-2">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item bi"><a href="<?php echo e(route('dashboard')); ?>">داشبورد</a></li>
                    <i class="fa fa-angle-left"></i>
                    <li class="breadcrumb-item bi"><a href="javascript:void(0)">بارنامه ها</a></li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="container w-100 mt-3" id="main-content">
        <div class="align-items-center card d-flex flex-row mb-3 gap-2 p-2 rounded-4">
            <div class="bg-teal text-white px-3 py-1 rounded">
                <i class="fas fa-info"></i>
            </div>
            <h6>در این قسمت میتوانید بارنامه ها را مشاهده کنید</h6>
        </div>
        <div class="card adminuiux-card mb-3">
            <?php
            $data = [
            ['label'=>'شماره','name' => 'waybill_number', 'data' => 'waybill_number'],
            ['label'=>'فرستنده','name' => 'sender_name', 'data' => 'sender_name'],
            ['label'=>'گیرنده','name' => 'receiver_name', 'data' => 'receiver_name'],
            ['label'=>'مبدا','name' => 'loading_origin', 'data' => 'loading_origin'],
            ['label'=>'مقصد','name' => 'unloading_destination', 'data' => 'unloading_destination'],
            ['label'=>'راننده','name' => 'drivers', 'data' => 'drivers'],
            ['label'=>'تاریخ','name' => 'waybill_date', 'data' => 'waybill_date'],
            ['label'=>'ساعت','name' => 'waybill_time', 'data' => 'waybill_time'],
            ['label'=>'فعالیت','name' => 'action', 'data' => 'action','orderable' => false]
            ];
            $route = route('admin.bol.data');
            ?>
            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginal1b6b63235b80b2d3f09c5dc940134363 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b6b63235b80b2d3f09c5dc940134363 = $attributes; } ?>
<?php $component = Modules\Core\app\View\Components\DataTableComponent::resolve(['route' => $route,'columns' => $data,'table' => 1] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('data-table-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Modules\Core\app\View\Components\DataTableComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b6b63235b80b2d3f09c5dc940134363)): ?>
<?php $attributes = $__attributesOriginal1b6b63235b80b2d3f09c5dc940134363; ?>
<?php unset($__attributesOriginal1b6b63235b80b2d3f09c5dc940134363); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b6b63235b80b2d3f09c5dc940134363)): ?>
<?php $component = $__componentOriginal1b6b63235b80b2d3f09c5dc940134363; ?>
<?php unset($__componentOriginal1b6b63235b80b2d3f09c5dc940134363); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('core::layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mohammad/freelanceProject/barbari/Modules/BOLManager/resources/views/admin/index.blade.php ENDPATH**/ ?>
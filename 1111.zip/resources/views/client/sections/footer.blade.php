<div id="shopify-section-footer-model-18" class="shopify-section index-section"><div data-section-id="footer-model-18"  data-section-type="Footer-model-18" class="footer-model-18">

    <div class="footer-logo" style="background-image:url('cdn/shop/files/footer_bg_1920X4394.jpg?v=1614749794');background-attachment:fixed;background-repeat:no-repeat;background-position:center center; ">

      <div class="footer-logo-img">

        <a href="index.html">
          <img class="normal-footer-logo" src="cdn/shop/files/footer-logo_200x4394.png?v=1614749794" alt="KEA Furniture (password: 1)" />
        </a>

      </div>

      <div class="footer-detail">

        <h4 style="color:#ffffff;">Newsletter</h4>



        <p style="color:#ffffff">329 Queensberry Street, North Melbourne VIC 3051, Australia</p>

        <form method="post" action="https://kea-furniture.myshopify.com/contact#contact_form" id="contact_form" accept-charset="UTF-8" class="contact-form"><input type="hidden" name="form_type" value="customer" /><input type="hidden" name="utf8" value="✓" />

        <div class="input-group">
          <input style="color:#ffffff;" type="email" value="" placeholder="Email address" name="contact[email]" class="mail" aria-label="Email address" >
          <input type="hidden" name="contact[tags]" value="newsletter">
          <button style="color:;" type="submit" class="btn subscribe" name="subscribe" value=""><i class="far fa-long-arrow-alt-right"></i></button>
        </div>

        </form>


        <ul class="footer-menu">

          <li class="current_page_item">
            <a style="color:#ffffff" href="index.html" class="menu_1">Home </a>
          </li>

          <li class="">
            <a style="color:#ffffff" href="collections/all.html" class="menu_2">Shop</a>
          </li>

          <li class="">
            <a style="color:#ffffff" href="blogs/news.html" class="menu_3">Blog</a>
          </li>

          <li class="">
            <a style="color:#ffffff" href="pages/about.html" class="menu_4">About</a>
          </li>

          <li class="">
            <a style="color:#ffffff" href="pages/contact.html" class="menu_5">Contact</a>
          </li>

        </ul>

      </div>
      <div class="footer_social_icons">

        <ul class="inline-list social-icons social-links-type-1">

          <li>
            <a style="color:;" class="icon-fallback-text twitt hexagon" target="blank" href="https://twitter.com/shopify" onmouseover="this.style.color='';" onmouseout="this.style.color='';" title="Twitter">
              <span class="fab fa-twitter" aria-hidden="true"></span>
            </a>
          </li>


          <li>
            <a style="color:;" class="icon-fallback-text fb hexagon" target="blank" href="https://www.facebook.com/shopify" onmouseover="this.style.color='';" onmouseout="this.style.color='';" title="Facebook">
              <span class="fab fa-facebook" aria-hidden="true"></span>
            </a>
          </li>


          <li>
            <a style="color:;" sclass="icon-fallback-text pin hexagon" target="blank" href="#" onmouseover="this.style.color='';" onmouseout="this.style.color='';" title="Pinterest">
              <span class="fab fa-pinterest" aria-hidden="true"></span>
            </a>
          </li>


          <li>
            <a style="color:;" class="icon-fallback-text google hexagon" target="blank" href="#" onmouseover="this.style.color='';" onmouseout="this.style.color='';" title="Google+" rel="publisher">
              <span class="fab fa-google-plus-g" aria-hidden="true"></span>
            </a>
          </li>


          <li>
            <a style="color:;" class="icon-fallback-text ins" target="blank" href="https://www.instagram.com/" onmouseover="this.style.color='';" onmouseout="this.style.color='';" title="Instagram">
              <span class="fab fa-instagram" aria-hidden="true"></span>
            </a>
          </li>


          <li>
            <a style="color:;" class="icon-fallback-text tumblr" target="blank" href="#" onmouseover="this.style.color='';" onmouseout="this.style.color='';" title="Tumblr">
              <span class="fab fa-tumblr" aria-hidden="true"></span>
            </a>
          </li>

          </ul>


      </div>


    </div>

    <div style="background:#000000;" class="grid__item copyright-section ">

      <p style="color:#ffffff;"  class="copyright">@2020 All rights reserved. </p>



      <div class="footer-icons">
        <ul class="inline-list payment-icons">

        </ul>
      </div>

    </div>

    <style>
      .footer-model-18 .footer_social_icons ul li a:hover { background:rgba(0,0,0,0) !important;color:#09acb5 !important; }
      .footer-model-18 .copyright-section p a { color:#ffffff; }
                                                                                                                                                                                                                                                                      .footer-model-18 .copyright-section p a:hover { color:#09acb5; }
                                                                                                                                                                                                                                                                          .footer-model-18 .footer-menu li a:hover { color:#09acb5 !important;}
                                                                                                                                                                                                                                                                              .footer-model-18 .footer_social_icons ul li a { color:#ffffff; }

                                                                                                                                                                                                                                                                                  .footer-model-18 .footer-logo::before{background:#000000; position:absolute; width:100%; height:100%;content:'';    left: 0;top: 0;right: 0;bottom: 0;opacity:0.8;}


    </style>
  </div>
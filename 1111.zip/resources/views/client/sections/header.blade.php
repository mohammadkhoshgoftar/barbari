<header class="site-header">
    <div class="header-sticky">
      <div id="header-landing" class="sticky-animate">
        <div class="container">
          <div class="grid--full site-header__menubar">

<h1 class="site-header__logo order-header" itemscope itemtype="http://schema.org/Organization">


  <a href="index.html" itemprop="url">
    <img class="normal-logo" src="cdn/shop/t/3/assets/logo827e.png?v=116837082786953183711582107505" alt="KEA Furniture (password: 1)" itemprop="logo">
  </a>


  </h1>

            <div class="menubar-section order-header">
              <div class="desktop-megamenu">
                <div id="shopify-section-navigation" class="shopify-section"><div class="nav-bar-mobile">
<nav class="nav-bar" role="navigation">
  <div class="site-nav-dropdown_inner">

<div class="menu-tool">
<ul class="site-nav">

  <li class=" ">
    <a class=" current color1" href="index.html">
      <span>
                                                                  Home
      </span>
    </a>

  </li>
  <li class=" dropdown  mega-menu ">
    <a class="  color2" href="collections/deck-chair.html">
      <span>
                                                                  Categories
      </span>
    </a>

    <div class="site-nav-dropdown">
<div class="container   style_1"> <!-- container div start -->




    <div class="col-1 parent-mega-menu">

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/alex-study-chair.html" class=" ">
                                                                  Desk Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/alex-study-chair.html" >
                                                                      Alex  Study Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/arm-accent-chair.html" >
                                                                      Arm Accent Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/armless-dining-chair.html" >
                                                                      Armless Dining Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/cushion-arm-chair.html" >
                                                                      Cushion Arm Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/cutout-comfortable-chair.html" >
                                                                      Cutout Comfortable Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/fabric-cushion-chair.html" >
                                                                      Fabric Cushion Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/handmade-armrest-chair.html" >
                                                                      Handmade Armrest Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/high-bar-stool.html" class=" ">
                                                                  Folding Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/high-leg-recliner.html" >
                                                                      High Leg Recliner
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/high-wooden-stool.html" >
                                                                      High Wooden Stool
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/mini-lcw-chair.html" >
                                                                      Mini LCW Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/mini-plastic-chair.html" >
                                                                      Mini Plastic Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/modern-furniture.html" >
                                                                      Modern Furniture
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/modern-lcw-chair.html" >
                                                                      Modern LCW Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/office-rolling-chair.html" >
                                                                      Office Rolling Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/office-rolling-chair.html" class=" ">
                                                                  Wood Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/ottoman-chair.html" >
                                                                      Ottoman Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/plywood-arm-chair.html" >
                                                                      Plywood Arm Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/revolving-office-chair.html" >
                                                                      Revolving Office Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/rove-shell-chair.html" >
                                                                      Rove Shell Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/soft-pink-coffee-table.html" >
                                                                      Soft Pink Coffee Table
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/velvet-office-chair.html" >
                                                                      Velvet Office Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/violet-iconic-chair.html" >
                                                                      Violet Iconic Chair
                                                                  </a>
          </li>

        </ul>

      </div>

   </div>



    <div class="col-2">



        <a href="#" title="">
          <img src="cdn/shop/files/menu-2-1_2000x5649.jpg?v=1614751884" alt="" />
        </a>



    </div>


  </div> <!-- container div end -->
</div>




  </li>


  <li class=" dropdown  mega-menu ">
    <a class="  color3" href="collections/executive-chair.html">
      <span>
                                                                  Products
      </span>
    </a>



    <div class="site-nav-dropdown">
<div class="container   style_2"> <!-- container div start -->




    <div class="col-1 parent-mega-menu">

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/wood-arm-chair.html" class=" ">
                                                                  Wing Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/wood-dining-chair.html" >
                                                                      Wood Dining Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/wood-arm-chair.html" >
                                                                      Wood Arm Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/white-arm-chair.html" >
                                                                      White Arm Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/violet-iconic-chair.html" class=" ">
                                                                  Armless Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/violet-iconic-chair.html" >
                                                                      Violet Iconic Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/vintage-arm-chair.html" >
                                                                      Vintage Arm Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/velvet-office-chair.html" >
                                                                      Velvet Office Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/velvet-office-chair.html" class=" ">
                                                                  Plastic Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/soft-pink-coffee-table.html" >
                                                                      Soft Pink Coffee Table
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/rove-shell-chair.html" >
                                                                      Rove Shell Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/revolving-office-chair.html" >
                                                                      Revolving Office Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/plywood-arm-chair.html" class=" ">
                                                                  Vintage Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/plywood-arm-chair.html" >
                                                                      Plywood Arm Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/ottoman-chair.html" >
                                                                      Ottoman Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/office-rolling-chair.html" >
                                                                      Office Rolling Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/modern-furniture.html" class=" ">
                                                                  Rolling Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/high-wooden-stool.html" >
                                                                      High Wooden Stool
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/high-bar-stool.html" >
                                                                      High Bar Stool
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/handmade-armrest-chair.html" >
                                                                      Handmade Armrest Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/fabric-cushion-chair.html" class=" ">
                                                                  Dining Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/alex-study-chair.html" >
                                                                      Alex  Study Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/arm-accent-chair.html" >
                                                                      Arm Accent Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/armless-dining-chair.html" >
                                                                      Armless Dining Chair
                                                                  </a>
          </li>

        </ul>

      </div>

   </div>



    <div class="col-2">

      <div class="col-left col-sm-6">
        <a href="#" title="">
          <img src="cdn/shop/files/menu-3-1_2000x5649.jpg?v=1614751884" alt="" />
        </a>
        <a href="#" title="">
          <img src="cdn/shop/files/menu-3-2_2000x5649.jpg?v=1614751884" alt="" />
        </a>
      </div>


      <div class="col-right col-sm-6">
        <a href="#" title="">
          <img src="cdn/shop/files/menu-3-3_2000x5649.jpg?v=1614751884" alt="" />
        </a>
      </div>


    </div>


  </div> <!-- container div end -->
</div>




  </li>







  <li class=" dropdown  mega-menu ">
    <a class="  color4" href="collections/wing-chair.html">
      <span>
                                                                  Brands
      </span>
    </a>






    <div class="site-nav-dropdown">
<div class="container   style_3"> <!-- container div start -->




    <div class="col-1 parent-mega-menu">

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/alex-study-chair.html" class=" ">
                                                                  Desk Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/alex-study-chair.html" >
                                                                      Alex  Study Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/arm-accent-chair.html" >
                                                                      Arm Accent Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/armless-dining-chair.html" >
                                                                      Armless Dining Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/cushion-arm-chair.html" >
                                                                      Cushion Arm Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/cutout-comfortable-chair.html" >
                                                                      Cutout Comfortable Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/fabric-cushion-chair.html" >
                                                                      Fabric Cushion Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/handmade-armrest-chair.html" >
                                                                      Handmade Armrest Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/high-bar-stool.html" class=" ">
                                                                  Folding Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/high-leg-recliner.html" >
                                                                      High Leg Recliner
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/high-wooden-stool.html" >
                                                                      High Wooden Stool
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/mini-lcw-chair.html" >
                                                                      Mini LCW Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/mini-plastic-chair.html" >
                                                                      Mini Plastic Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/modern-furniture.html" >
                                                                      Modern Furniture
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/modern-lcw-chair.html" >
                                                                      Modern LCW Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/office-rolling-chair.html" >
                                                                      Office Rolling Chair
                                                                  </a>
          </li>

        </ul>

      </div>

      <div class="inner col-xs-12 col-sm-4">
        <!-- Menu level 2 -->
        <a  href="products/office-rolling-chair.html" class=" ">
                                                                  Wood Chair

                                                                  </a>

        <ul class="dropdown">

          <!-- Menu level 3 -->
          <li>
            <a href="products/ottoman-chair.html" >
                                                                      Ottoman Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/plywood-arm-chair.html" >
                                                                      Plywood Arm Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/revolving-office-chair.html" >
                                                                      Revolving Office Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/rove-shell-chair.html" >
                                                                      Rove Shell Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/soft-pink-coffee-table.html" >
                                                                      Soft Pink Coffee Table
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/velvet-office-chair.html" >
                                                                      Velvet Office Chair
                                                                  </a>
          </li>

          <!-- Menu level 3 -->
          <li>
            <a href="products/violet-iconic-chair.html" >
                                                                      Violet Iconic Chair
                                                                  </a>
          </li>

        </ul>

      </div>

   </div>



   <div class="col-2">

        <div class="col-left">
          <div class="widget-featured-product ">

            <div class="widget-product">
              <div class="products-grid">








<div class="grid-item product-item " id="product-4464349184060">
<a href="products/office-rolling-chair.html" class="product-grid-image">
  <img src="cdn/shop/products/shop-64_large60e2.jpg?v=1582103795" alt="Office Rolling Chair">
</a>



<div class="details">
  <a class="product-title" href="products/office-rolling-chair.html">
                                                                      Office Rolling Chair
                                                                  </a>
  <span class="shopify-product-reviews-badge" data-id="4464349184060"></span>
  <div class="price-box">

      <p class="regular-product">
        <span><span class=money>$178.00</span></span>
      </p>

  </div>

</div>
</div>
              </div>
            </div>
          </div>
        </div>


       <div class="col-right">
          <a href="#" title="">
            <img src="cdn/shop/files/menu-4-1_2000x5649.jpg?v=1614751884" alt="" />
          </a>
        </div>

    </div>


  </div> <!-- container div end -->
</div>




  </li>







  <li class="  dropdown">
    <a class="menu__moblie   color5" href="#">
      <span>
                                                                  Pages
      </span>
    </a>







    <ul class="site-nav-dropdown level-one">

<li >
  <a href="pages/about.html" class="">
    <span>
                                                                  About Us
                                                                  </span>

  </a>
  <ul class="site-nav-dropdown level-two">

  </ul>
</li>

<li >
  <a href="blogs/news.html" class="">
    <span>
                                                                  Blog
    </span>

  </a>
  <ul class="site-nav-dropdown level-two">

  </ul>
</li>

<li >
  <a href="pages/contact.html" class="">
    <span>
                                                                  Contact Us
                                                                  </span>

  </a>
  <ul class="site-nav-dropdown level-two">

  </ul>
</li>

<li >
  <a href="pages/faqs.html" class="">
    <span>
                                                                  Faq
    </span>

  </a>
  <ul class="site-nav-dropdown level-two">

  </ul>
</li>

</ul>





  </li>

</ul>
</div>
  </div>
</nav>
</div>

</div>
              </div>
            </div>
            <div id="shopify-section-header-model-14" class="shopify-section">
<ul class="menu-icon">

<li class="header-search">
  <a href="search.html" class="site-header__link site-header__search js-drawer-open-top">
    <span class="fa fa-search" aria-hidden="true"></span>
  </a>
</li>


          <li class="menu-right-icon">
            <div class="menu_bar_right">
              <div class="slidedown_section">
                <a  id="Togglemodal" title="Log in" class="icon-cart-arrow"><i class="fas fa-user-cog"></i></a>
                <div id="slidedown-modal">
                  <div class="header-panel-top">
                    <ul>


                      <li>
                        <div class="customer_account">
                          <ul>


                            <li>
                              <a href="account/login.html" title="Log in"> <i class="fas fa-sign-in-alt icons" aria-hidden="true"></i> Log in</a>
                            </li>
                            <li>
                              <a href="account/register.html" title="Create account">  <i class="fas fa-user" aria-hidden="true"></i> Create account</a>
                            </li>

                            <li>
                              <a href="pages/wishlist.html" title="Wishlist"> <i class="far fa-heart" aria-hidden="true"></i> Wishlist</a>
                            </li>

                          </ul>
                        </div>
                      </li>

                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </li>



<li class="header-bar__module cart header_cart">
 <!-- Mini Cart Start -->
<div class="baskettop">
<div class="wrapper-top-cart">
  <a href="cart.html" id="ToggleDown" class="icon-cart-arrow">


    <i class="fas fa-cart-plus"></i>
    <div id="cartCount">0
        </div>


  </a>
  <div id="slidedown-cart" style="display:none">
    <!--  <h3>Shopping cart</h3>-->
    <div class="no-items">
      <p>Your cart is currently empty!</p>
      <p class="text-continue"><a class="btn" href="javascript:void(0)">Continue shopping</a></p>
    </div>
    <div class="has-items">
      <ul class="mini-products-list">

      </ul>
      <div class="summary">
        <p class="total">
          <span class="label">Cart total :</span>
          <span class="price"><span class=money>$0.00</span></span>
        </p>
      </div>
      <div class="actions">
        <button class="btn" onclick="window.location='index.html'"><i class="fas fa-check"></i>Check Out</button>
        <button class="btn text-cart" onclick="window.location='cart.html'"><i class="fas fa-shopping-basket"></i>View Cart</button>
      </div>
    </div>
  </div>
</div>
</div> <!-- End Top Header -->
</li>

<li class="header-mobile">
  <div class="menu-block visible-phone"><!-- start Navigation Mobile  -->
    <div id="showLeftPush">
      <i class="fa fa-bars" aria-hidden="true">  </i>
    </div>
  </div><!-- end Navigation Mobile  -->
</li>
</ul>


<style>
/* Top block */
.header-type-14 .top_bar { background: ; }
.header-type-14 .top_bar li, .header-type-14 .top_bar span { color:;}
.header-type-14 .top_bar a { color:;}
.header-type-14 .top_bar a:hover, .header-type-14 .top_bar a:hover span { color:;}

/* Logo block */
.header-type-14 .site-header__logo a { color:#767676;}
                                                                      .header-type-14 .site-header__logo a:hover { color:#09acb5;}

                                                                          /* Menu  block */
                                                                          .header-type-14 .site-header,.mobile-nav-section ,.header-type-14 .sticky-animate{background: #ffffff;}
                                                                              .header-type-14 .menu-tool ul li {color: ;}
.header-type-14 .menu-tool ul li a,.mobile-nav-section .mobile-nav-trigger {color:#767676;}
                                                                                  .header-type-14 .menu-tool ul li a:hover,.header-type-14 .menu-tool .site-nav > li > a.current:hover {color:#09acb5;}
                                                                                      .header-type-14 .menu-tool .site-nav >  li > a.current {color:#09acb5;}
                                                                                          .header-type-14 .site-nav-dropdown,#MobileNav,.mobile-nav__sublist { background: #ffffff;}
.header-type-14 .site-nav-dropdown .inner > a {color: #000000;}
                                                                                              .header-type-14 .site-nav-dropdown .inner > a:hover {color: #09acb5;}
                                                                                                  .header-type-14 .site-nav-dropdown .inner .dropdown a,.header-type-14 .menu-tool .site-nav .site-nav-dropdown li a,.header-type-14 .site-nav .widget-featured-product .product-title,.header-type-14 .site-nav .widget-featured-product .widget-title h3,#MobileNav a,.mobile-nav__sublist a,.site-nav .widget-featured-nav .owl-prev a,.site-nav .widget-featured-nav .owl-next a  {color: #767676;}
.header-type-14 .site-nav-dropdown .inner .dropdown a:hover,.header-type-14 .menu-tool .site-nav .site-nav-dropdown li a:hover,.header-type-14 .site-nav-dropdown .inner .dropdown a.current,.header-type-14 .menu-tool .site-nav .site-nav-dropdown li a.current,.header-type-14 .site-nav .widget-featured-product .product-title:hover,#MobileNav a.current,.mobile-nav__sublist a.current,.site-nav .widget-featured-nav .owl-prev a:hover,.site-nav .widget-featured-nav .owl-next a:hover {color: #09acb5;}


/* Dropdown block */
.header-type-14 .menu_icon #Togglemodal i {color: ;}
                                                                                                  .header-type-14 .menu_icon #Togglemodal i:hover {color: ;}
                                                                                                  .header-type-14 #slidedown-modal {background: ;}
                                                                                                  .header-type-14 #slidedown-modal ul li a {color:;}
                                                                                                  .header-type-14 #slidedown-modal ul li a:hover {color:;}


                                                                                                  /* Search block */
                                                                                                  .header-type-14 .search-bar input[type="search"] {color:#767676;}
.header-type-14 .header-search span  {color:#767676;}
                                                                                                      .header-type-14 .header-search span:hover {color:#09acb5;}
                                                                                                          .header-type-14 .search-bar__form, .header-type-14 #SearchDrawer  {  }
                                                                                                          .header-type-14 .search-bar__form button,.header-type-14 .search-bar__icon-button { color:#767676;}
                                                                                                              .header-type-14 .search-bar__form button:hover,.header-type-14 .search-bar__icon-button:hover { color:#09acb5;}

                                                                                                                  .header-type-14 .search-bar input[type="search"]::-webkit-input-placeholder  { /* Chrome/Opera/Safari */
                                                                                                                      color:#767676;
                                                                                                                  }
.header-type-14 .search-bar input[type="search"]::-moz-placeholder { /* Firefox 19+ */
                                                                                                                      color:#767676;
                                                                                                                  }
.header-type-14 .search-bar input[type="search"]:-ms-input-placeholder { /* IE 10+ */
                                                                                                                      color:#767676;
                                                                                                                  }
.header-type-14 .search-bar input[type="search"]:-moz-placeholder { /* Firefox 18- */
                                                                                                                      color:#767676;
                                                                                                                  }

.header-type-14 .menu-icon li a:hover , .header-type-14 .header-mobile:hover{color:#09acb5;}


</div>
          </div>
        </div>
      </div>
    </div>
  </header>
<link href="{{asset('client/assets/css/frame.scss639b.css')}}" rel="stylesheet" type="text/css" media="all" >
<link href="{{asset('client/assets/css/style6bda.css')}}" rel="stylesheet" type="text/css" media="all" >
<link href="{{asset('client/assets/css/slickd433.css')}}" rel="stylesheet" type="text/css" media="all" >
<link href="{{asset('client/assets/css/prettyPhotoe93e.css')}}" rel="stylesheet" type="text/css" media="all" >
<link href="{{asset('client/assets/css/lightslider1700.css')}}" rel="stylesheet" type="text/css" media="all" >
<link href="{{asset('client/assets/css/animate7c2f.css')}}" rel="stylesheet" type="text/css" media="all" >
<link href="{{asset('client/assets/css/font-all.minbe2b.css')}}" rel="stylesheet" type="text/css" media="all" >
<link href="{{asset('client/assets/css/karla.css')}}" rel="stylesheet" type="text/css">